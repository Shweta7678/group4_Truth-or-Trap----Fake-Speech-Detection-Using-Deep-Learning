import os
import shutil
import tempfile
import base64
import gradio as gr
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import librosa
import librosa.display
import soundfile as sf

# ---------------------------------------
# Model imports
# ---------------------------------------
import torch

# ---------------------------------------
# IMPORTANT: Add your model class here
# ---------------------------------------
# You need to either import your model class or define it here
# For example:
# from your_model_file import YourModelClass
# or define it below:

class YourModelClass(torch.nn.Module):
    """
    REPLACE THIS with your actual model class
    Import it from your model file or define it here
    """
    def __init__(self):
        super().__init__()
        # Add your model layers here
        pass
    
    def forward(self, x):
        # Add your forward pass here
        pass

# ---------------------------------------
# Model loading and prediction
# ---------------------------------------
class AudioFakeDetectionModel:
    def __init__(self, model_path):
        self.model = None
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.load_model(model_path)
    
    def load_model(self, model_path):
        """Load the trained model from file"""
        try:
            # Check if the file contains state_dict or complete model
            checkpoint = torch.load(model_path, map_location=self.device)
            
            if isinstance(checkpoint, dict) and 'state_dict' in checkpoint:
                # If it's a checkpoint with state_dict
                self.model = YourModelClass()
                self.model.load_state_dict(checkpoint['state_dict'])
            elif isinstance(checkpoint, dict) and not hasattr(checkpoint, 'eval'):
                # If it's just a state_dict dictionary
                self.model = YourModelClass()
                self.model.load_state_dict(checkpoint)
            else:
                # If it's a complete model
                self.model = checkpoint
            
            self.model.to(self.device)
            self.model.eval()
            print(f"Model loaded successfully from {model_path}")
        except Exception as e:
            print(f"Error loading model: {e}")
            self.model = None
    
    def predict(self, audio_data):
        """Make prediction using the loaded model"""
        if self.model is None:
            # Fallback to placeholder if model failed to load
            return self._placeholder_detection(audio_data)
        
        try:
            sr, y = audio_data
            
            # Convert audio to tensor (assuming your model expects raw audio)
            audio_tensor = torch.FloatTensor(y).unsqueeze(0).to(self.device)
            
            # Make prediction using your softmax logic
            with torch.no_grad():
                # Get model output
                _,pred = self.model(audio_tensor)
                
                # Apply softmax
                softmax_probs = torch.softmax(pred, dim=1)
                
                # Get predicted class and confidence
                _, predicted_class = torch.max(softmax_probs, 1)
                
                # Get the softmax probability values of the predicted class
                predicted_class_probs = softmax_probs.gather(1, predicted_class.unsqueeze(1)).squeeze(1)
                
                # Convert class prediction (0=fake/spoofed, 1=real/bonafide)
                is_fake = predicted_class.item() == 0
                confidence = predicted_class_probs.item()
            
            return {
                "prediction": "FAKE" if is_fake else "REAL",
                "confidence": confidence,
                "raw_score": confidence,
                "predicted_class": predicted_class.item()
            }
            
        except Exception as e:
            print(f"Error in prediction: {e}")
            return self._placeholder_detection(audio_data)
    
    def _placeholder_detection(self, audio_data):
        """Fallback detection when model is not available"""
        sr, y = audio_data
        y = y.astype(np.float32)
        import random
        
        # Simple placeholder logic
        is_fake = random.choice([True, False])
        conf = random.uniform(0.6, 0.95)
        
        return {
            "prediction": "FAKE" if is_fake else "REAL",
            "confidence": conf,
            "features": {"placeholder": True}
        }

# Initialize model at startup
MODEL_PATH = "/home/padman/Downloads/epoch_4.pth"  # Update this path to your actual model file
audio_model = AudioFakeDetectionModel(MODEL_PATH)

# ---------------------------------------
# Logo and Asset Loading with Error Handling
# ---------------------------------------
def load_base64(path):
    """Load file as base64 with error handling."""
    try:
        with open(path, "rb") as f:
            return base64.b64encode(f.read()).decode()
    except Exception as e:
        print(f"Warning: Could not load {path} - {str(e)}")
        return None

# Direct path for the assets
HCL_B64 = None
IITM_B64 = None
BG_B64 = None

# Path to the assets
hcl_path = "assets/hcl_logo.jpg"
iitm_path = "assets/iit_mandi_logo.jpg"
bg_path = "assets/bg.jpg"  # Direct path to the background image

# Try to load HCL logo
if os.path.exists(hcl_path):
    HCL_B64 = load_base64(hcl_path)

# Try to load IITM logo
if os.path.exists(iitm_path):
    IITM_B64 = load_base64(iitm_path)

# Try to load background image
if os.path.exists(bg_path):
    BG_B64 = load_base64(bg_path)

# ---------------------------------------
# Matplotlib styling and color palette
# ---------------------------------------
plt.style.use('ggplot')
COLORS = {
    "primary":   "#4361ee",
    "secondary": "#3a0ca3",
    "accent":    "#f72585",
    "light":     "#f8f9fa",
    "dark":      "#212529",
    "success":   "#4cc9f0",
    "real":      "#4caf50",
    "fake":      "#f44336",
}

# ---------------------------------------
# Audio processing / plotting
# ---------------------------------------
def process_audio(audio_path, n_mels=80, hop_length=512, win_length=2048,
                  fmin=50, fmax=8000, display_type="mel"):
    """Load audio and return a matplotlib Figure of the chosen visualization."""
    y, sr = librosa.load(audio_path, sr=16000)
    fig, ax = plt.subplots(figsize=(12,6))
    fig.patch.set_facecolor(COLORS["light"])
    ax.set_facecolor(COLORS["light"])
    title_font = {'fontsize':16, 'fontweight':'bold', 'color':COLORS["dark"]}

    if display_type == "mel":
        mel = librosa.feature.melspectrogram(
            y=y, sr=sr, n_mels=n_mels,
            hop_length=hop_length, win_length=win_length,
            fmin=fmin, fmax=fmax
        )
        S_db = librosa.power_to_db(mel, ref=np.max)
        img = librosa.display.specshow(
            S_db, x_axis='time', y_axis='mel', sr=sr,
            fmin=fmin, fmax=fmax, ax=ax, cmap='viridis'
        )
        ax.set_title(f'Mel Spectrogram ({n_mels} bands)', **title_font)

    elif display_type == "chroma":
        chroma = librosa.feature.chroma_stft(
            y=y, sr=sr, hop_length=hop_length, win_length=win_length
        )
        img = librosa.display.specshow(
            chroma, x_axis='time', y_axis='chroma', sr=sr,
            hop_length=hop_length, ax=ax, cmap='plasma'
        )
        ax.set_title('Chromagram', **title_font)

    elif display_type == "waveform":
        librosa.display.waveshow(y, sr=sr, ax=ax, color=COLORS["primary"])
        ax.set_title('Waveform', **title_font)
        ax.grid(True, alpha=0.3)
        plt.tight_layout(pad=2.0)
        return fig

    elif display_type == "mfcc":
        mfccs = librosa.feature.mfcc(
            y=y, sr=sr, n_mfcc=20, hop_length=hop_length
        )
        img = librosa.display.specshow(
            mfccs, x_axis='time', y_axis='mfcc', sr=sr,
            hop_length=hop_length, ax=ax, cmap='magma'
        )
        ax.set_title('MFCC', **title_font)

    # add colorbar for spectrogram/MFCC
    cbar = fig.colorbar(img, ax=ax,
                        format="%+2.f dB" if display_type in ["mel","mfcc"] else "%+2.f")
    cbar.ax.tick_params(labelsize=10)
    ax.set_xlabel('Time (s)', fontsize=12)
    ax.set_ylabel(display_type.capitalize(), fontsize=12)
    ax.tick_params(labelsize=10)
    plt.tight_layout(pad=2.0)
    return fig

def save_audio(audio_data):
    """Write the (sr, np_audio) tuple to a temp WAV and return its path."""
    if audio_data is None:
        return None
    sr, y = audio_data
    temp_dir = tempfile.mkdtemp()
    temp_path = os.path.join(temp_dir, "temp.wav")
    sf.write(temp_path, y, sr)
    return temp_path

def cleanup_temp_files():
    """Remove temp dirs created during audio saving."""
    base = tempfile.gettempdir()
    for item in os.listdir(base):
        if item.startswith("tmp"):
            path = os.path.join(base, item)
            if os.path.isdir(path):
                try:
                    shutil.rmtree(path)
                except:
                    pass

# ---------------------------------------
# Fake/real detection logic
# ---------------------------------------
def detect_fake_audio(audio_data):
    if audio_data is None:
        return None
    
    # Use the model to make prediction
    result = audio_model.predict(audio_data)
    
    # Extract features for display
    sr, y = audio_data
    y = y.astype(np.float32)
    rms = np.sqrt(np.mean(y**2))
    zcr = librosa.feature.zero_crossing_rate(y).mean()
    sc = librosa.feature.spectral_centroid(y=y, sr=sr).mean()
    
    # Add features to result
    result["features"] = {
        "rms": float(rms),
        "zero_crossing_rate": float(zcr),
        "spectral_centroid": float(sc)
    }
    
    return result

def format_result_html(result):
    if result is None:
        return """
        <div class="result-box">
            <h3>Error Processing Audio</h3>
            <p>There was a problem analyzing your audio. Please try again.</p>
        </div>"""
    pred = result["prediction"]
    conf = result["confidence"] * 100
    feats = result["features"]
    conf_str = f"{conf:.1f}%"
    box_class = "real" if pred=="REAL" else "fake"
    fill_class = "real-fill" if pred=="REAL" else "fake-fill"
    features_html = f"""
    <table class="features-table">
      <tr><th>Feature</th><th>Value</th><th>Interpretation</th></tr>
      <tr><td>RMS Energy</td><td>{feats['rms']:.6f}</td>
          <td>{'High' if feats['rms']>0.05 else 'Low'}</td></tr>
      <tr><td>Zero Crossing Rate</td><td>{feats['zero_crossing_rate']:.6f}</td>
          <td>{'Typical' if 0.05<feats['zero_crossing_rate']<0.15 else 'Unusual'}</td></tr>
      <tr><td>Spectral Centroid</td><td>{feats['spectral_centroid']:.2f} Hz</td>
          <td>{'Balanced' if 1000<feats['spectral_centroid']<3000 else 'Suspicious'}</td></tr>
    </table>
    """
    return f"""
    <div class="result-box {box_class}">
      <h2>{pred} AUDIO</h2>
      <p>Confidence level: {conf_str}</p>
      <div class="confidence-meter">
        <div class="confidence-fill {fill_class}" style="width:{conf}%"></div>
      </div>
      <h3>Analysis Details</h3>
      {features_html}
      <p style="margin-top:1.5rem; font-style:italic;">
        {'Authentic recording.' if pred=='REAL' else 'Signs of synthetic generation.'}
      </p>
    </div>
    """

def generate_mel_spectrogram(audio_data, n_mels=80, hop_length=512, win_length=2048, fmin=50, fmax=8000):
    """Generate a mel spectrogram from audio data and return as an image."""
    if audio_data is None:
        return None
    
    sr, y = audio_data
    temp_path = save_audio(audio_data)
    if temp_path is None:
        return None
    
    try:
        fig = process_audio(temp_path, n_mels=n_mels, hop_length=hop_length, 
                          win_length=win_length, fmin=fmin, fmax=fmax, 
                          display_type="mel")
        return fig
    except Exception as e:
        print(f"Error generating spectrogram: {e}")
        return None
    finally:
        if temp_path and os.path.exists(temp_path):
            os.remove(temp_path)

# ---------------------------------------
# Gradio interface
# ---------------------------------------
def create_audio_analyzer_app():
    # Custom CSS with hardcoded background image and transparent upload section
    if BG_B64:
        background_css = f"""
        .gradio-container {{
          background-image: url('data:image/jpeg;base64,{BG_B64}');
          background-size: cover;
          background-position: center;
          background-attachment: fixed;
        }}
        """
    else:
        background_css = """
        .gradio-container {
          background: linear-gradient(135deg, #4361ee 0%, #3a0ca3 100%);
        }
        """
    
    custom_css = background_css + """
    /* Dimming overlay */
    body::before {
      content: "";
      position: fixed; top:0; left:0; width:100%; height:100%;
      background-color: rgba(0,0,0,0.6); z-index:-1;
    }
    /* Transparent container for the audio upload */
    .container { 
        max-width:1200px!important; margin:2rem auto!important;
        background-color: rgba(255,255,255,0.5)!important;
        border-radius:15px!important; box-shadow:0 8px 32px rgba(0,0,0,0.2)!important;
        padding:2rem!important; position:relative!important; z-index:1!important;
    }
    .header { text-align:center; margin-bottom:2rem; }
    .title-box { background:white; padding:1.5rem; border-radius:10px;
      box-shadow:0 4px 12px rgba(0,0,0,0.1); margin-bottom:1.5rem; }
    .header h1 { font-size:2.5rem!important; font-weight:700!important;
      color:#3a0ca3!important; margin-bottom:0.5rem!important; }
    .header h2 { font-size:1.5rem!important; font-weight:500!important;
      color:#4361ee!important; }
    .logo-container { display:flex; justify-content:center;
      align-items:center; gap:8rem!important; margin-bottom:2rem;
      background:white; padding:1.5rem; border-radius:12px;
      box-shadow:0 4px 12px rgba(0,0,0,0.05); }
    .logo { max-height:80px!important; width:auto!important;
      object-fit:contain!important; }
    .welcome-text { font-size:1.1rem!important; line-height:1.6!important;
      text-align:center; max-width:800px; margin:0 auto 2rem auto;
      background:white; padding:1.5rem; border-radius:10px;
      box-shadow:0 4px 12px rgba(0,0,0,0.05); }
    .gr-button.gr-button-lg { font-size:1.1rem!important;
      padding:0.75rem 1.5rem!important; }
    .gr-button-primary { background-color:#4361ee!important; }
    .gr-box, .gr-panel { border-radius:12px!important;
      box-shadow:0 4px 12px rgba(0,0,0,0.05)!important;
      background:white!important; }
    .footer { text-align:center; margin-top:3rem;
      padding:1rem; font-size:0.9rem; color:#6c757d;
      background:white; border-radius:10px;
      box-shadow:0 4px 12px rgba(0,0,0,0.05); }
    .about-section h3 { font-size:1.3rem!important;
      font-weight:600!important; color:#3a0ca3!important; }
    .about-section p, .about-section li { font-size:1rem!important;
      line-height:1.6!important; }
    .result-box { padding:2rem; text-align:center;
      border-radius:12px; margin-top:1rem;
      transition:all 0.3s ease; background:white; }
    .result-box h2 { font-size:2.5rem!important;
      font-weight:700!important; margin-bottom:1rem!important; }
    .result-box p { font-size:1.2rem!important; }
    .real { background-color: rgba(76,175,80,0.1);
      border:2px solid #4caf50; }
    .fake { background-color: rgba(244,67,54,0.1);
      border:2px solid #f44336; }
    .confidence-meter { width:100%; height:1rem;
      background:#e9ecef; border-radius:0.5rem; overflow:hidden; margin:1rem 0; }
    .confidence-fill { height:100%; }
    .real-fill { background:#4caf50; }
    .fake-fill { background:#f44336; }
    .spectrogram-section { margin-top:2rem; padding:1.5rem;
      background:white; border-radius:12px;
      box-shadow:0 4px 12px rgba(0,0,0,0.05); }
    .spectrogram-title { font-size:1.5rem!important; 
      font-weight:600!important; color:#3a0ca3!important;
      text-align:center; margin-bottom:1rem; }
    .features-table { width:100%; border-collapse:collapse; margin:1rem 0; }
    .features-table th, .features-table td { 
      padding:0.5rem; text-align:left; border-bottom:1px solid #dee2e6; }
    .features-table th { background:#f8f9fa; font-weight:600; }
    """

    theme = gr.themes.Soft(
        primary_hue=gr.themes.colors.blue,
        secondary_hue=gr.themes.colors.purple,
    ).set(
        button_primary_background_fill="#4361ee",
        button_primary_background_fill_hover="#3a0ca3",
        button_secondary_background_fill="#f8f9fa",
        button_secondary_background_fill_hover="#e9ecef",
        button_secondary_text_color="#212529",
        button_secondary_border_color="#ced4da",
        background_fill_primary="#f8f9fa",
        block_title_text_color="#212529",
        block_label_text_color="#212529",
    )

    with gr.Blocks(
        title="AITech Hackathon 2025 - Audio Fakeness Detector",
        theme=theme,
        css=custom_css,
    ) as app:
        with gr.Column(elem_classes="container"):
            # Header
            with gr.Column(elem_classes="header"):
                with gr.Column(elem_classes="title-box"):
                    gr.Markdown("# 🚀 AITech Hackathon 2025")
                    gr.Markdown("## Truth or Trap : Fake Speech Detector")
            
            # Logos with fallback
            with gr.Row(elem_classes="logo-container"):
                logo_html = """
                <div style="display:flex;justify-content:center;align-items:center;gap:8rem;">
                """
                if HCL_B64:
                    logo_html += f"""
                    <img src="data:image/jpeg;base64,{HCL_B64}" 
                         alt="HCL Logo" class="logo" />
                    """
                else:
                    logo_html += """
                    <div style="text-align:center;">
                        <h3>HCL Logo</h3>
                        <p>[Image not found]</p>
                    </div>
                    """
                
                if IITM_B64:
                    logo_html += f"""
                    <img src="data:image/jpeg;base64,{IITM_B64}" 
                         alt="IIT Mandi Logo" class="logo" />
                    """
                else:
                    logo_html += """
                    <div style="text-align:center;">
                        <h3>IIT Mandi Logo</h3>
                        <p>[Image not found]</p>
                    </div>
                    """
                
                logo_html += "</div>"
                gr.HTML(logo_html)
            
            # Welcome text
            gr.Markdown(
                """
                <div class="welcome-text">
                  Welcome to the Fake Speech Detector for the AITech Hackathon 2025.
                  Record or upload your audio to analyze whether it's authentic or artificially generated.
                  This professional tool uses advanced AI to detect synthetic speech and audio manipulations.
                </div>
                """,
                elem_classes="welcome-text"
            )
            
            # Main controls & output
            with gr.Row():
                with gr.Column(scale=1, min_width=300):
                    audio_input = gr.Audio(
                        label="Record or Upload Audio",
                        type="numpy",
                        sources=["microphone","upload"],
                        elem_classes="gr-box"
                    )
                    analyze_btn = gr.Button("Analyze Audio", variant="primary", size="lg")
                
                with gr.Column(scale=2, min_width=550):
                    result_html = gr.HTML(
                        """
                        <div class="result-box">
                          <h3>Upload or record audio to analyze</h3>
                          <p>The system will determine if the audio is real or artificially generated.</p>
                        </div>
                        """
                    )
            
            # Mel Spectrogram Section
            with gr.Column(elem_classes="spectrogram-section"):
                gr.Markdown('<div class="spectrogram-title">Audio Mel Spectrogram Visualization</div>')
                mel_spectrogram = gr.Plot(
                    label="Mel Spectrogram", 
                    show_label=True,
                    container=True,
                    elem_id="mel-spectrogram"
                )
                gr.Markdown("""
                <p style="text-align:center; font-size:0.9rem; color:#6c757d; margin-top:0.5rem;">
                    The mel spectrogram shows the frequency content of the audio over time. 
                    This visualization helps identify patterns characteristic of real or synthetic audio.
                </p>
                """)
            
            # About & footer
            with gr.Accordion("About This Tool", open=False, elem_classes="about-section"):
                gr.Markdown("""
                ### Overview
                This audio analysis tool uses advanced AI to detect whether a sample is authentic or generated.
                The tool analyzes various acoustic features including spectral patterns and temporal dynamics.
                
                ### Mel Spectrogram Analysis
                The mel spectrogram visualization displays the audio's frequency content over time, 
                converted to the mel scale which better approximates human auditory perception.
                """)
            gr.Markdown(
                '<div class="footer">© 2025 AITech Hackathon | IIT Mandi & HCL Technologies</div>',
                elem_classes="footer"
            )

        # Event callbacks
        def on_analyze_click(audio):
            if audio is None:
                return """
                <div class="result-box">
                  <h3>No Audio Detected</h3>
                  <p>Please record or upload audio.</p>
                </div>""", None
            
            result = detect_fake_audio(audio)
            spectrogram = generate_mel_spectrogram(
                audio
            )
            
            return format_result_html(result), spectrogram

        analyze_btn.click(
            fn=on_analyze_click, 
            inputs=[audio_input], 
            outputs=[result_html, mel_spectrogram]
        )
        
        audio_input.change(
            fn=on_analyze_click,
            inputs=[audio_input],
            outputs=[result_html, mel_spectrogram]
        )

    return app

# ---------------------------------------
# Launch
# ---------------------------------------
if __name__ == "__main__":
    app = create_audio_analyzer_app()
    app.launch(share=True, debug=True, allowed_paths=["assets"])
    cleanup_temp_files()
